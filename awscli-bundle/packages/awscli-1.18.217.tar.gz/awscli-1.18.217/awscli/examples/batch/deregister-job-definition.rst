**To deregister a job definition**

This example deregisters a job definition called sleep10.

Command::

  aws batch deregister-job-definition --job-definition sleep10

