**To add a delegate to a resource**

The following ``associate-delegate-to-resource`` command adds a delegate to a resource. ::

    aws workmail associate-delegate-to-resource \
        --organization-id m-d281d0a2fd824be5b6cd3d3ce909fd27 \
        --resource-id r-68bf2d3b1c0244aab7264c24b9217443 \
        --entity-id S-1-1-11-1111111111-2222222222-3333333333-3333

This command produces no output.
